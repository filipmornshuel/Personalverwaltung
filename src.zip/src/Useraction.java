import javax.swing.*;

public class Useraction {

    public static int CREATE_PERSON = 0;
    public static int CHANGE_VALUE = 1;
    public static int SET_ASSIGNMENT = 2;
    public static int DELETE_PERSON = 3;
    private String[] actionDescription;
    private String entry;


    public Useraction(HRPerson hrPerson, Person person, int action){

    }

    public String getEntry(){
        return entry;
    }
}
