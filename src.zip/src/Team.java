public class Team {

    private String[] designations;

    public Team(){}

    public void addTeam(String team){}

    public String getTeam(int index){}

    public void removeTeam(int index){}

    public int getSize(){}
}
