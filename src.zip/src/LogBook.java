import java.io.*;
import java.util.Vector;

public class LogBook {

    private Vector<String> entries;
    private static LogBook instance;
    private File file;
    private BufferedReader reader;
    private BufferedWriter writer;
    private Boolean fileWritingEnabled = false;

    public LogBook(){
        file = new File("logboook.log");
        try {
            if (file.createNewFile() == false){
                reader = new BufferedReader(new FileReader(file));
                readFile();
                reader.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            writer = new BufferedWriter(new FileWriter(file));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public LogBook getLogBookInstance(){
        if (instance == null){
            instance = new LogBook();
        }
        return instance;
    }

    public void addEntry(String entry){
        if (fileWritingEnabled == true){
            writeFile(entry);
        }
    }

    public String getEntry(int index){
        return entries.get(index);
    }

    public Integer getSize(){
        return entries.size();
    }

    public void logBookClose(){}

    public void printLog(){
        for (int i = 0; i < getSize(); i++){
            System.out.println(entries.get(i));
        }
    }

    private void writeFile(String entry){
        try {
            writer.append(entry);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void readFile(){
        while (true) {
            try {
                if (!(reader.ready() == true)) break;
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                reader.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
