public class JobFunctions {

    private String[] designations;

    public JobFunctions(){}

    public void addJobFunction(String function){}

    public String getJobFunction(int index){
        return designations[index];
    }

    public void removeJobFunction(int index){}

    public int getSize(){}
}
