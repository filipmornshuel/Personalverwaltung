public class Company {

    private String name;
    private Department[] departments;

    public Company(String name){
        this.name = name;
        departments = new Department[5];
    }

    public String getCompanyName() {
        return name;
    }

    public void addDepartment(Department department){
    }

    public Department getDepartments(int index) {
        return departments[index];
    }

    public String getDepartmentsName(){}

    public void removeDepartment(int index){}

    public int gerNumberOfDepartments(){}
}
