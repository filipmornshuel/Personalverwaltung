public class Participation {

    private JobFunctions[] functions;
    private Team[] teams;
    private Person owner;

    public Participation(Person person){
        owner = person;
    }

    public void addFunction(JobFunctions jobFunction){

    }

    public String getFunctionName(int index){

    }

    public void removeFunction(int index){

    }

    public int getNumberOfFunctions(){

    }

    public void addTeam(Team team){

    }

    public String getTeamName(int index){

    }

    public void removeTeam(int index){

    }

    public int getNumberOfTeams(){

    }
}
