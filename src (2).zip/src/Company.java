public class Company {

    private String name;
    private Department[] departments;

    public Company(String name){
        this.name = name;
    }

    public String getCompanyName() {
        return name;
    }

    public void addDepartment(Department department){
        departments[departments.length + 1] = department;
    }

    public Department getDepartments(int index) {
        return departments[index];
    }

    public String getDepartmentsName(int index){
        return departments[index].getName();
    }

    public void removeDepartment(int index){}

    public int getNumberOfDepartments(){
        return departments.length;
    }
}
