public class JobFunctions {

    private String[] designations;
    private String name;

    public JobFunctions(){}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void addJobFunction(String function){}

    public String getJobFunction(int index){
        return designations[index];
    }

    public void removeJobFunction(int index){}

    public int getSize(){
        return designations.length;
    }
}
