public class Participation {

    private JobFunctions[] functions;
    private Team[] teams;
    private Person owner;

    public Participation(Person person){
        owner = person;
    }

    public void addFunction(JobFunctions jobFunction){

    }

    public String getFunctionName(int index){
        return functions[index].getName();
    }

    public void removeFunction(int index){

    }

    public int getNumberOfFunctions(){
        return functions.length;
    }

    public void addTeam(Team team){

    }

    public String getTeamName(int index){
        return teams[index].getName();
    }

    public void removeTeam(int index){

    }

    public int getNumberOfTeams(){
        return teams.length;
    }
}
