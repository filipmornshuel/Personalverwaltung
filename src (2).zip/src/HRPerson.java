import javax.swing.*;

public class HRPerson extends Person {

    private int modus;
    private String pwd;

    public HRPerson(String fristName, String lastName, ImageIcon photo, int modus) {
        super(fristName, lastName, photo);
        this.modus = modus;
    }

    public void change(Person person, int modus){

    }

    public void setModus(int modus) {
        this.modus = modus;
    }

    public int getModus() {
        return modus;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getPwd() {
        return pwd;
    }

    public void writeLogEntry(Useraction useraction, Person person){
        Useraction ua = new Useraction(this, person, useraction);
        LogBook log = new LogBook();
        log.getLogBookInstance();
        log.addEntry(ua.getEntry());


    }
}
