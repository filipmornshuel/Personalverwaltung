public class Department {

    private String name;
    private Person[] members;

    public Department(String name){
    }

    public String getName() {
        return name;
    }

    public void addMember(Person person){}

    public Person getMembers(int index) {
        return members[index];
    }

    public void removeMember(int index){

    }

    public int getNumberOfMembers(){
        return members.length;
    }
}
