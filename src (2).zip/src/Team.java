public class Team {

    private String[] designations;
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Team(String name){}

    public void addTeam(String team){}

    public String getTeam(int index){
        return designations[index];
    }

    public void removeTeam(int index){}

    public int getSize(){
        return designations.length;
    }
}
